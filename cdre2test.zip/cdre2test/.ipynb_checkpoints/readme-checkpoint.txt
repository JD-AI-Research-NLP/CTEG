1. model文件夹里面存的是Bert参数和proto模型，proto模型分为调用sentence encoder和算距离两部分
2.fewshot_re_kit文件夹里存的数据处理文件，训练框架，sentence——encoder
3.train和test文件指定参数和数据集

在调用train文件之后，train文件会调用训练框架framework.py，框架依次是调用dataloader.py处理数据，得到batch，调用proto.py进入模型，在proto中调用sentence—encoder
sentence_encoder分为embedding和encoder，其中embedding文件是我们模型的BERT部分（虽然现在BERT也用作encoder了，但是文件名我没改），encoder是我们模型的transformer部分

注意我在BERT中加gate是直接改的 import pytorch_pretrained_bert包里的源码，可以把这个包里的modeling.py保留好，下次迁移环境直接替换掉原来的就行了

所需环境：python3 pytorch jdk

训练命令：python train.py proto 5 5 0   (模型名字，N,K,噪声比例)  Q的数量在train.py文件中固定成5，要改的话需要在文件里改，噪声比例我们没用到，就一直是0就行
测试命令：python test.py proto 5 5 0

PS: 进行数据处理的时候要保证上一次处理生成的中间文件全部删掉了，不然会append产生错误。